package classNumber;


import java.util.Scanner;

public class Lab6_class {
	
	public int a;
	public int b;
	
	
	
	public static int Max(int a,int b)
	{
		int max=0;
		
		if(a>max && a>b )
		{
			max=a;
		}
		else
		{
			max=b;
		}
		return max;
	}
	
	public int main()
	{
		Scanner sc = new Scanner(System.in);
		
		a = sc.nextInt();
		b = sc.nextInt();
		Max(a,b);
		return 0;
	}

}

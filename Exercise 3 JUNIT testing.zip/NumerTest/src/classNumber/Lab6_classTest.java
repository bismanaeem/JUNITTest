package classNumber;

import static org.junit.Assert.*;

import org.junit.Test;

public class Lab6_classTest {

	@Test
	public final void testMax() {
		int a = 1;
		int b = 2;
		
		int expectedOutput=2;
		int actualOutput=Lab6_class.Max(a, b);
		
		assertEquals(expectedOutput,actualOutput);
		
	}
	
	

	@Test
	public final void testMain() {
		
	}

}

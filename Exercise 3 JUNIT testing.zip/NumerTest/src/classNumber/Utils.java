package classNumber;

public class Utils {
	
	public int x;
	public String W;

	public static int Square(int x)
	{
		int sq_result;
		
		
		sq_result = x*x;
		return sq_result;
	}
	
	public static int CountA(String W)
	{
		int count=0;
		
		for(int i=0;i<W.length();i++)
		{
			if(W.charAt(i)=='a' || W.charAt(i)=='A')
			{
				count++;
			}
		}
		
		
		return count;
	}
}

package classNumber;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.Before;
import org.junit.After;

class UtilsTest {
    @After
	@Test
	final void testSquare() {
		int x=4;
		int expectedOutput=16;
		int actualOutput=Utils.Square(x);
		
		assertEquals(expectedOutput,actualOutput);
		
	}
    @Before
	@Test
	final void checknull()
	{
		int x=3;
		
	
		
		if(x>0)
		{
			assertNotNull(x);
		}
		
		else 
			if(x==0)
			{
				assertNull(x);
			}
	}
	
	
	@Test
	final void testCountA() {
		
		String W="aAbbh";
		int count =0;
		int expectedOutput=2;
		int actualOutput=Utils.CountA(W);
		assertEquals(expectedOutput,actualOutput);
		
	}
	@Test
	public void whenDerivedExceptionThrown_thenAssertionSucceds() {
	    Exception exception = assertThrows(RuntimeException.class, () -> {
	        Integer.parseInt("1a");
	    });
	 
	    String expectedMessage = "Aaab";
	    String actualMessage = exception.getMessage();
	 
	    assertFalse(actualMessage.contains(expectedMessage));
	}

}
